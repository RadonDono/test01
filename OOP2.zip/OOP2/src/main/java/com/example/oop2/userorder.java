package com.example.oop2;

import com.example.oop2.Order.Comment;
import com.example.oop2.Order.Order;
import com.example.oop2.Order.Restaurant;
import com.example.oop2.Persons.User;
import com.example.oop2.controller.UserController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class userorder implements Initializable {
    UserController userController=new UserController(UserController.usercon);
    @FXML
    ListView list;
    @FXML
    TextArea textarea;
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    public void back(ActionEvent event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("userMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void comment(ActionEvent event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("userordercomment.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        list.getItems().add("in progress order:");
        list.getItems().addAll(UserController.usercon.inProgressOrdersID);
        list.getItems().add("finished order:");
        list.getItems().addAll(UserController.usercon.finishedOrdersID);
    }

    public void list(MouseEvent mouseEvent) {
        textarea.setText(Order.getOrder(Integer.parseInt(list.getSelectionModel().getSelectedItem().toString())).toString());
        UserController.order=Order.getOrder(Integer.parseInt(list.getSelectionModel().getSelectedItem().toString()));
    }

    public void send(ActionEvent event) {
    }
}
