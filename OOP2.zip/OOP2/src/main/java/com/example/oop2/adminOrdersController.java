package com.example.oop2;

import com.example.oop2.Persons.RestaurantOwner;
import com.example.oop2.controller.RestaurantOwnerController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class adminOrdersController implements Initializable
{
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    public Exception showadminMenu(ActionEvent event, RestaurantOwner r) throws IOException {
        RestaurantOwnerController.using=r;
        root= FXMLLoader.load(getClass().getResource("adminMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
    RestaurantOwnerController restaurantOwnerController=new RestaurantOwnerController(RestaurantOwnerController.using);
    @FXML
    Button button;
    @FXML
    ChoiceBox<String> orderType;
    @FXML
    private Label show;
    @FXML
    private ListView<String> list;


    public void orderTypeAction()
    {
        list.getItems().removeAll();
        if(orderType.getValue().equals("Received"))
        {
            button.setText("accept");
            button.setDisable(false);
            list.getItems().addAll(RestaurantOwnerController.showArr(RestaurantOwnerController.restaurant.receivedOrders));
        }
        else if(orderType.getValue().equals("In Progress"))
        {
            button.setText("Finish");
            button.setDisable(false);
            list.getItems().addAll(RestaurantOwnerController.showArr(RestaurantOwnerController.restaurant.currentOrders));
        }
        else if(orderType.getValue().equals("Finished"))
        {
            button.setDisable(true);
            list.getItems().addAll(RestaurantOwnerController.showArr(RestaurantOwnerController.restaurant.finishedOrders));
        }
    }

    public void listAction()
    {
        show.setText(list.getSelectionModel().getSelectedItem());
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String[] temp={"Received","In Progress","Finished"};
        orderType.getItems().addAll(temp);
        list.getItems().addAll(temp);
    }

    public void back(ActionEvent event) throws IOException {
        showadminMenu(event,RestaurantOwnerController.using);
    }
}
