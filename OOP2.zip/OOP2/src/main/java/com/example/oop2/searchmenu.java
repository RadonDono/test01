package com.example.oop2;

import com.example.oop2.Order.Restaurant;
import com.example.oop2.Persons.User;
import com.example.oop2.controller.UserController;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class searchmenu implements Initializable {
    UserController userController=new UserController(UserController.usercon);
    ActionEvent eventt;
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    public Exception showuserMenu(ActionEvent event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("userMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
    @FXML
    public Exception showuserrestaurantmenu(ActionEvent event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("userRestaurantMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
    @FXML
    TextField nametext;
    @FXML
    ChoiceBox<String> chose;
    @FXML
    ListView list;

    public void search(ActionEvent event) {
        eventt=event;
        list.getItems().removeAll();
        String name=nametext.getText();
        String chos=chose.getValue();
        if (name!=null&&chos!=null){
            switch (chos){
                case "Id":
                    list.getItems().removeAll();
                    list.getItems().add(Restaurant.getRestaurant(Integer.parseInt(name)));
                    break;
                case "name":
                    list.getItems().removeAll();
                    list.getItems().addAll(userController.searchrestaurant(name));
                    break;
            }
        }
    }

    public void back(ActionEvent event) throws IOException {
        showuserMenu(event);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        list.getItems().removeAll();
        chose.getItems().add("Id");
        chose.getItems().add("name");
        list.getItems().addAll(Restaurant.restaurants);
    }

    public void list(MouseEvent mouseEvent) throws IOException {
        if (eventt!=null) {
            String[] x = list.getSelectionModel().getSelectedItem().toString().split(" ");
            UserController.restaurant_now = Restaurant.getRestaurant(Integer.parseInt(x[x.length - 1]));
            showuserrestaurantmenu(eventt);
        }
        else{
            Alert al=new Alert(Alert.AlertType.CONFIRMATION);
            al.setTitle("Eror!");
            al.setContentText("please search restaurant");
            Optional<ButtonType> result=al.showAndWait();
        }

    }
}
