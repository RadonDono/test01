package com.example.oop2;

import com.example.oop2.Persons.RestaurantOwner;
import com.example.oop2.controller.RestaurantOwnerController;
import com.example.oop2.enums.Message;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class admiedit implements Initializable {
    RestaurantOwnerController restaurantOwnerController=new RestaurantOwnerController(RestaurantOwnerController.using);
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    public Exception showadminMenu(ActionEvent event, RestaurantOwner r) throws IOException {
        RestaurantOwnerController.using=r;
        root= FXMLLoader.load(getClass().getResource("adminMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
    @FXML
    TextField ChangingValue;
    @FXML
    ChoiceBox<String> changeBox;
    @FXML
    Label name;
    @FXML
    Label Adress;
    @FXML
    Label foodType;

    public void change(ActionEvent event) throws IOException {
        if (ChangingValue!=null&&changeBox!=null){
            switch (changeBox.getValue()){
                case "foodtype":
                    if(!this.restaurantOwnerController.checkprogressrestaurantfoods().equals(Message.progressfood)) {
                        Alert al=new Alert(Alert.AlertType.CONFIRMATION);
                        al.setTitle("eror!");
                        al.setContentText("Are you sure");
                        Optional<ButtonType> result=al.showAndWait();
                        if(result.isEmpty()){

                        } else if (result.get()==ButtonType.OK) {
                            Message message = this.restaurantOwnerController.changefoodtype(ChangingValue.getText());
                            showedit(event);

                        }
                    }else {
                        Alert al=new Alert(Alert.AlertType.CONFIRMATION);
                        al.setTitle("eror!");
                        al.setContentText("foods are in progress");
                        Optional<ButtonType> result=al.showAndWait();

                    }
                    break;
                case "location":
                        this.restaurantOwnerController.editlocation(Integer.parseInt(ChangingValue.getText()));
                        showedit(event);
                    }
            }
        else {
            Alert al=new Alert(Alert.AlertType.CONFIRMATION);
            al.setTitle("eror!");
            al.setContentText("Are you sure");
            Optional<ButtonType> result=al.showAndWait();
        }
    }

    private void showedit(Event event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("adminEdit.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void back(ActionEvent event) throws IOException {
        showadminMenu(event,RestaurantOwnerController.using);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        changeBox.getItems().add("foodtype");
        changeBox.getItems().add("location");
        name.setText(RestaurantOwnerController.using.getName());
        foodType.setText(RestaurantOwnerController.using.getFoodType(RestaurantOwnerController.restaurant.getRestaurantID()));
        Adress.setText(String.valueOf(restaurantOwnerController.showlocation()));
    }
}
