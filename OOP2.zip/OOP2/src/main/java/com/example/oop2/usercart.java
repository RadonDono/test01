package com.example.oop2;

import com.example.oop2.Order.Order;
import com.example.oop2.controller.UserController;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class usercart implements Initializable {
    UserController userController=new UserController(UserController.usercon);
    @FXML
    ListView list;
    String entekhab;
    String id;
    @FXML
    Label price;
    @FXML
    Label restaurant;
    @FXML
    ChoiceBox<String> chose;
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    public void back(ActionEvent event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("userMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void delete() {
        if (entekhab!=null&&chose.getValue()!=null){
            UserController.usercon.removeFoodFromOrder(Integer.parseInt(entekhab),Integer.parseInt(chose.getValue()));
            listshow();
        }
        else{
            Alert al=new Alert(Alert.AlertType.CONFIRMATION);
            al.setTitle("Eror!");
            al.setContentText("select a food");
            Optional<ButtonType> result=al.showAndWait();
        }
    }
    public void add() throws IOException {
        Alert al=new Alert(Alert.AlertType.CONFIRMATION);
        al.setTitle("eror!");
        al.setContentText("Are you sure?");
        Optional<ButtonType> result=al.showAndWait();
        if(result.isEmpty()){

        } else if (result.get()==ButtonType.OK) {
            userController.confirmorder();
            ActionEvent event=new ActionEvent();
            back(event);
        }
    }
    public void list(){
        String[] m=list.getSelectionModel().getSelectedItem().toString().split(" ");
        entekhab =m[m.length-1];
    }
    void setChose(){
        chose.getItems().addAll(userController.showcartid());
    }

    public void chois(ActionEvent event) {
        id=chose.getValue().toString();
        listshow();
    }

    private void listshow() {
        list.getItems().addAll(Order.getOrder(Integer.parseInt(id)));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setChose();
    }

    public void send(ActionEvent event) {
    }
}
