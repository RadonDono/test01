package com.example.oop2.LocationAndMap;

public class pair{
    int v;
    int w;

    public pair(int v, int w) {
        this.v = v;
        this.w = w;
    }
}
