package com.example.oop2;

import com.example.oop2.Order.Comment;
import com.example.oop2.Persons.RestaurantOwner;
import com.example.oop2.controller.RestaurantOwnerController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

public class admincommentcontroller implements Initializable {
    private Stage stage;
    private Scene scene;
    private Parent root;
    RestaurantOwnerController restaurantOwnerController=new RestaurantOwnerController(RestaurantOwnerController.using);
    @FXML
    TextArea textarea;
    @FXML
    Label textl;

        @FXML
    Button sendbutton;
        @FXML
    ListView list;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ArrayList<Comment> x=(restaurantOwnerController.showcomment());
        ArrayList<String> ids=new ArrayList<>();
        for (Comment com:x) {
            ids.add(String.valueOf(com.getcommenid()));
        }
        list.getItems().addAll(ids);
    }

    public void send(ActionEvent event) throws IOException {
        if (textarea!=null){
            if (!restaurantOwnerController.hasrespond(((String) list.getSelectionModel().getSelectedItem()))){
                restaurantOwnerController.setrespond(((String) list.getSelectionModel().getSelectedItem()),textarea.getText());
                showadminMenu(event,RestaurantOwnerController.using);
            }
            else{
                Alert al=new Alert(Alert.AlertType.CONFIRMATION);
                al.setTitle("Eror!");
                al.setContentText("you have alrady arespond");
                Optional<ButtonType> result=al.showAndWait();
            }
        }
        else{
            Alert al=new Alert(Alert.AlertType.CONFIRMATION);
            al.setTitle("Eror!");
            al.setContentText("enter somthing");
            Optional<ButtonType> result=al.showAndWait();
        }
    }

    public void listaction(MouseEvent mouseEvent) {
        textl.setText(Comment.getComment(Integer.parseInt((String) list.getSelectionModel().getSelectedItem())).toString());
    }
    @FXML
    public Exception showadminMenu(ActionEvent event, RestaurantOwner r) throws IOException {
        RestaurantOwnerController.using=r;
        root= FXMLLoader.load(getClass().getResource("adminMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
}
