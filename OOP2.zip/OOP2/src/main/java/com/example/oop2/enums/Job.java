package com.example.oop2.enums;

public enum Job {
    Delivery,Restaurantowner,User;
}
