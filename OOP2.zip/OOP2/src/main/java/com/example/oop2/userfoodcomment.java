package com.example.oop2;

import com.example.oop2.Order.Comment;
import com.example.oop2.controller.RestaurantOwnerController;
import com.example.oop2.controller.UserController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

public class userfoodcomment implements Initializable {
    UserController userController=new UserController(UserController.usercon);
    @FXML
    Label rating;
    @FXML
    TextArea commentText;
    @FXML
    Label textarea;
    @FXML
    ChoiceBox<String> ratingBox;
    @FXML
    ListView Comments;
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    public void back(ActionEvent event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("userRestaurantMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    public void send(ActionEvent event) {
        if (commentText.getText() != null && ratingBox.getValue() != null) {
            userController.addrestaurantcomment(commentText.getText());
            userController.addrate(Integer.parseInt(ratingBox.getValue()));
        } else {
            Alert al = new Alert(Alert.AlertType.CONFIRMATION);
            al.setTitle("Eror!");
            al.setContentText("enter somthing");
            Optional<ButtonType> result = al.showAndWait();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ArrayList<Comment> x=(UserController.restaurant_now.receivedComments);
        ArrayList<String> ids=new ArrayList<>();
        for (Comment com:x) {
            ids.add(String.valueOf(com.getcommenid()));
        }
        Comments.getItems().addAll(ids);
        rating.setText(String.valueOf(userController.getrate()));
        ratingBox.getItems().add("1");
            ratingBox.getItems().add("2");
            ratingBox.getItems().add("3");
            ratingBox.getItems().add("4");
            ratingBox.getItems().add("5");
    }


    public void list(MouseEvent mouseEvent) {
        textarea.setText(Comment.getComment(Integer.parseInt((String)Comments.getSelectionModel().getSelectedItem())).toString());
    }
}
