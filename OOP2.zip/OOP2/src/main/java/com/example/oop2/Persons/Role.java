package com.example.oop2.Persons;
import com.example.oop2.*;

public enum Role {
    Deliver,User,RestaurantOwner;
}
