package com.example.oop2;

import com.example.oop2.Order.Restaurant;
import com.example.oop2.controller.UserController;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class UserMenu implements Initializable {
    UserController userController=new UserController(UserController.usercon);
    @FXML
    ListView suggestlist;
    @FXML
    ListView restaurantlist;
    private Stage stage;
    private Scene scene;
    private Parent root;
    public Exception welcomeMenu(ActionEvent event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("welcomeMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
        return null;
    }
    public Exception showcharge(ActionEvent event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("chargeMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
    public Exception showsearch(Event event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("searchMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
    public Exception showcart(Event event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("userCart.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
    public Exception showorder(Event event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("userOrderMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }

    public void chargebtn(ActionEvent event) throws IOException {
        showcharge(event);
    }

    public void orderbtn(ActionEvent event) throws IOException {
        showorder(event);
    }

    public void searchbtn(ActionEvent event) throws IOException {
        showsearch(event);
    }

    public void cartbtn(ActionEvent event) throws IOException {
        showcart(event);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        restaurantlist.getItems().addAll(Restaurant.restaurants);
        suggestlist.getItems().addAll(UserController.usercon.suggestSystem());
    }
}
