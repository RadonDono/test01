package com.example.oop2.Order;

public enum Status
{
    //your average ordinary status class!
    InCart,NeedRestaurantAccept,NeedDeliverAccept,InWay,Delivered,Finished,Canceled;
}