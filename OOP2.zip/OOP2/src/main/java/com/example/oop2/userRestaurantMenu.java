package com.example.oop2;

import com.example.oop2.Order.Food;
import com.example.oop2.controller.UserController;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class userRestaurantMenu implements Initializable {
    UserController userController=new UserController(UserController.usercon);
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    Button orderButton;
    @FXML
    ListView list;
    @FXML
    Label label;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        list.getItems().addAll(UserController.restaurant_now.activeFoods);
    }
    public Exception showrestaurantcomment(Event event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("userFoodComments.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
    public Exception showcom(MouseEvent event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("comments.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
    public void add(ActionEvent event) {
        if (list.getSelectionModel().getSelectedItem()!=null){
            Alert al=new Alert(Alert.AlertType.CONFIRMATION);
            al.setTitle("Eror!");
            al.setContentText("Are you sure you want this?");
            Optional<ButtonType> result=al.showAndWait();
            if(result.isEmpty()){
            } else if (result.get()==ButtonType.OK) {
                String[] x=list.getSelectionModel().getSelectedItem().toString().split(" ");
                userController.selectfood(x[x.length-1]);
            }

        }
        else {
            Alert al=new Alert(Alert.AlertType.CONFIRMATION);
            al.setTitle("Eror!");
            al.setContentText("please chose correct role");
            Optional<ButtonType> result=al.showAndWait();
        }
    }



    public Exception searchMenu(Event event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("searchMenu.fxml"));
        stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

        return null;
    }
    public void comment(ActionEvent event) throws IOException {
        showrestaurantcomment(event);
    }

    public void showcomment(MouseEvent mouseEvent) throws IOException {
        String[] x=list.getSelectionModel().getSelectedItem().toString().split(" ");
        UserController.food=Food.getFood(Integer.parseInt(x[x.length-1]));
        showcom(mouseEvent);
    }
}
